import Image from "next/image";
import { TributeImage } from "@/components/ui/tribute-image";
import { notFound } from "next/navigation";
import { announcements } from "@/lib/data";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { ReadAloudButton } from "@/components/accessibility/ReadAloudButton";
import { AnnouncementActions } from "@/components/announcement/AnnouncementActions";
import { ReminderForm } from "@/components/announcement/reminder-form";
import { TributeWall } from "@/components/announcement/TributeWall";
import { Calendar, MapPin, CheckCircle } from "lucide-react";

export async function generateStaticParams() {
  return announcements.map((announcement) => ({
    slug: announcement.slug,
  }));
}

export default async function AnnouncementPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const announcement = announcements.find((a) => a.slug === slug);

  if (!announcement) {
    notFound();
  }

  return (
    <div className="min-h-screen flex flex-col bg-ivory-50">
      <Header />
      <main className="flex-1">
        {/* Hero / Header */}
        <div className="bg-deep-green-900 text-ivory-50 py-12 md:py-20">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-4 flex items-center justify-center gap-3">
              {announcement.name}
              {announcement.verified && <CheckCircle className="h-8 w-8 text-blue-400 fill-blue-900/20" />}
            </h1>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sage-200 text-lg">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                <span>{new Date(announcement.dateOfBirth).getFullYear()} - {new Date(announcement.dateOfDeath).getFullYear()}</span>
              </div>
              <div className="hidden sm:block">•</div>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                <span>{announcement.county} County</span>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 md:px-6 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column: Photo & Actions */}
            <div className="lg:col-span-1 space-y-8">
              <div className="relative aspect-[4/5] w-full overflow-hidden rounded-lg shadow-lg border-4 border-white">
                <TributeImage
                  src={announcement.photoUrl}
                  name={announcement.name}
                  alt={announcement.name}
                  fill
                  className="object-cover"
                  priority
                />
              </div>

              <div className="bg-white p-6 rounded-lg border border-sage-200 shadow-sm space-y-4">
                <AnnouncementActions
                  tributeCount={announcement.tributes}
                  announcementTitle={announcement.name}
                />
              </div>

              <div className="bg-white p-6 rounded-lg border border-sage-200 shadow-sm">
                <ReminderForm announcementTitle={announcement.name} />
              </div>
            </div>

            {/* Right Column: Bio, Details, Guestbook */}
            <div className="lg:col-span-2 space-y-12">
              <section>
                <div className="flex items-center justify-between mb-6 border-b-2 border-sage-200 pb-2">
                  <h2 className="text-3xl font-serif font-bold text-deep-green-900">
                    Biography
                  </h2>
                  <ReadAloudButton text={announcement.bio} />
                </div>
                <div className="prose prose-lg text-sage-800 max-w-none">
                  <p>{announcement.bio}</p>
                </div>
              </section>

              <section className="bg-sage-50 p-8 rounded-lg border border-sage-200">
                <h2 className="text-2xl font-serif font-bold text-deep-green-900 mb-6">
                  Funeral Arrangements
                </h2>
                <div className="space-y-4 text-sage-800">
                  <p>{announcement.funeralDetails}</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-deep-green-900 mb-6">
                  Guestbook & Tributes
                </h2>
                <TributeWall />
              </section>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
