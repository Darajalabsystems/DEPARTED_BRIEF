import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory-50">
      <Header />
      <main className="flex-1 container mx-auto px-4 md:px-6 py-12">
        <div className="max-w-3xl mx-auto space-y-12">
          <section className="text-center">
            <h1 className="text-4xl font-serif font-bold text-deep-green-900 mb-6">About DepartedBrief</h1>
            <p className="text-lg text-sage-800 leading-relaxed">
              DepartedBrief is a digital sanctuary dedicated to preserving the memories of our loved ones within the Liberian community, both at home and in the diaspora. We bridge the gap between tradition and technology, ensuring that every life is honored with the dignity it deserves.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-serif font-bold text-deep-green-900 mb-4">Our Mission</h2>
            <p className="text-sage-800 leading-relaxed">
              To provide a respectful, accessible, and culturally attuned platform for death announcements, tributes, and funeral planning resources. We aim to support families during their time of grief by simplifying the process of sharing information while maintaining the solemnity of our traditions.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-serif font-bold text-deep-green-900 mb-6">Frequently Asked Questions</h2>
            <div className="grid gap-6">
              <Card className="border-sage-200">
                <CardHeader>
                  <CardTitle className="text-lg">How do I submit an announcement?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sage-700">Simply click on the "Submit Announcement" button, follow the 3-step wizard to provide details about the deceased, upload photos, and choose a package that suits your needs.</p>
                </CardContent>
              </Card>
              <Card className="border-sage-200">
                <CardHeader>
                  <CardTitle className="text-lg">What payment methods are accepted?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sage-700">We accept Mobile Money (MTN/Orange), Credit Cards (via Stripe), PayPal, and EcoBank transfers to accommodate users in Liberia and abroad.</p>
                </CardContent>
              </Card>
              <Card className="border-sage-200">
                <CardHeader>
                  <CardTitle className="text-lg">Can I edit an announcement after posting?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sage-700">Yes, please contact our support team with your order details, and we will assist you with any necessary corrections.</p>
                </CardContent>
              </Card>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-serif font-bold text-deep-green-900 mb-6">Grief Resources</h2>
            <div className="bg-sage-50 p-6 rounded-lg border border-sage-200">
              <ul className="space-y-4">
                <li>
                  <a href="#" className="text-deep-green-700 hover:underline font-medium">Liberian Mental Health Association</a>
                  <p className="text-sm text-sage-600">Support and counseling services.</p>
                </li>
                <li>
                  <a href="#" className="text-deep-green-700 hover:underline font-medium">Diaspora Grief Support Group</a>
                  <p className="text-sm text-sage-600">Online community for Liberians abroad.</p>
                </li>
                <li>
                  <a href="#" className="text-deep-green-700 hover:underline font-medium">Traditional Rites & Customs Guide</a>
                  <p className="text-sm text-sage-600">Understanding our funeral traditions.</p>
                </li>
              </ul>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}
