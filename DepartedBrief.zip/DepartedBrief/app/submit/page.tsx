"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { submitSchema, SubmitFormValues } from "@/lib/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Check, ChevronRight, ChevronLeft, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

const steps = [
  { id: 1, title: "Package & Payment" },
  { id: 2, title: "Deceased Info" },
  { id: 3, title: "Tribute & Photo" },
];

export default function SubmitPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<SubmitFormValues>({
    resolver: zodResolver(submitSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      county: "",
      bio: "",
      funeralDetails: "",
      tier: "basic",
      paymentMethod: "mobile_money",
    },
    mode: "onChange",
  });

  const { register, handleSubmit, formState: { errors }, trigger, watch, setValue } = form;
  const formData = watch();

  const nextStep = async () => {
    let fieldsToValidate: (keyof SubmitFormValues)[] = [];
    if (currentStep === 1) {
      // Validate Payment Step
      fieldsToValidate = ["tier", "paymentMethod"];
    } else if (currentStep === 2) {
      // Validate Deceased Info
      fieldsToValidate = ["firstName", "lastName", "dateOfBirth", "dateOfDeath", "county", "bio"];
    }

    const isStepValid = await trigger(fieldsToValidate);
    if (isStepValid) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const prevStep = () => {
    setCurrentStep((prev) => prev - 1);
  };

  const onSubmit = async (data: SubmitFormValues) => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));
    console.log(data);
    setIsSubmitting(false);
    // Redirect to confirmation (mock)
    window.location.href = "/confirmation";
  };

  return (
    <div className="min-h-screen flex flex-col bg-ivory-50">
      <Header />
      <main className="flex-1 container mx-auto px-4 md:px-6 py-12">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-serif font-bold text-deep-green-900 mb-4">Submit an Announcement</h1>
            <div className="flex items-center justify-between relative">
              <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-sage-200 -z-10" />
              {steps.map((step) => (
                <div key={step.id} className="flex flex-col items-center bg-ivory-50 px-2">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors",
                    currentStep >= step.id ? "bg-deep-green-900 border-deep-green-900 text-white" : "bg-white border-sage-300 text-sage-400"
                  )}>
                    {currentStep > step.id ? <Check className="h-4 w-4" /> : step.id}
                  </div>
                  <span className={cn(
                    "text-xs mt-2 font-medium",
                    currentStep >= step.id ? "text-deep-green-900" : "text-sage-400"
                  )}>{step.title}</span>
                </div>
              ))}
            </div>
          </div>

          <Card className="border-sage-200 shadow-md">
            <form onSubmit={handleSubmit(onSubmit)}>
              <CardContent className="p-6 md:p-8">

                {/* STEP 1: PACKAGE & PAYMENT (Moved from Step 3) */}
                {currentStep === 1 && (
                  <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="space-y-4">
                      <h3 className="text-lg font-serif font-bold text-deep-green-900">Select a Package</h3>
                      <RadioGroup onValueChange={(value) => setValue("tier", value as any)} defaultValue={formData.tier} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className={cn("border rounded-lg p-4 cursor-pointer hover:border-deep-green-500 transition-colors", formData.tier === "basic" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <div className="flex items-center space-x-2 mb-2">
                            <RadioGroupItem value="basic" id="basic" />
                            <Label htmlFor="basic" className="font-bold text-lg">Basic</Label>
                          </div>
                          <p className="text-2xl font-bold text-deep-green-900 mb-2">$15</p>
                          <ul className="text-xs text-sage-600 space-y-1 list-disc list-inside">
                            <li>Standard Listing</li>
                            <li>1 Photo</li>
                            <li>30 Days Active</li>
                          </ul>
                        </div>
                        <div className={cn("border rounded-lg p-4 cursor-pointer hover:border-deep-green-500 transition-colors", formData.tier === "premium" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <div className="flex items-center space-x-2 mb-2">
                            <RadioGroupItem value="premium" id="premium" />
                            <Label htmlFor="premium" className="font-bold text-lg">Premium</Label>
                          </div>
                          <p className="text-2xl font-bold text-deep-green-900 mb-2">$35</p>
                          <ul className="text-xs text-sage-600 space-y-1 list-disc list-inside">
                            <li>Featured Listing</li>
                            <li>Gallery (up to 10 photos)</li>
                            <li>Permanent Archive</li>
                            <li>Guestbook</li>
                          </ul>
                        </div>
                        <div className={cn("border rounded-lg p-4 cursor-pointer hover:border-deep-green-500 transition-colors", formData.tier === "custom" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <div className="flex items-center space-x-2 mb-2">
                            <RadioGroupItem value="custom" id="custom" />
                            <Label htmlFor="custom" className="font-bold text-lg">Custom</Label>
                          </div>
                          <p className="text-2xl font-bold text-deep-green-900 mb-2">$75</p>
                          <ul className="text-xs text-sage-600 space-y-1 list-disc list-inside">
                            <li>All Premium Features</li>
                            <li>Video Tribute</li>
                            <li>Dedicated Support</li>
                            <li>Printed Program Design</li>
                          </ul>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-serif font-bold text-deep-green-900">Payment Method</h3>
                      <RadioGroup onValueChange={(value) => setValue("paymentMethod", value as any)} defaultValue={formData.paymentMethod} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className={cn("border rounded-lg p-3 cursor-pointer flex items-center gap-3", formData.paymentMethod === "mobile_money" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <RadioGroupItem value="mobile_money" id="mobile_money" />
                          <Label htmlFor="mobile_money" className="cursor-pointer flex-1">Mobile Money (MTN/Orange)</Label>
                        </div>
                        <div className={cn("border rounded-lg p-3 cursor-pointer flex items-center gap-3", formData.paymentMethod === "stripe" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <RadioGroupItem value="stripe" id="stripe" />
                          <Label htmlFor="stripe" className="cursor-pointer flex-1">Credit Card (Stripe)</Label>
                        </div>
                        <div className={cn("border rounded-lg p-3 cursor-pointer flex items-center gap-3", formData.paymentMethod === "paypal" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <RadioGroupItem value="paypal" id="paypal" />
                          <Label htmlFor="paypal" className="cursor-pointer flex-1">PayPal</Label>
                        </div>
                        <div className={cn("border rounded-lg p-3 cursor-pointer flex items-center gap-3", formData.paymentMethod === "ecobank" ? "border-deep-green-500 bg-sage-50" : "border-sage-200")}>
                          <RadioGroupItem value="ecobank" id="ecobank" />
                          <Label htmlFor="ecobank" className="cursor-pointer flex-1">EcoBank</Label>
                        </div>
                      </RadioGroup>

                      <div className="space-y-4 pt-4 border-t border-sage-200">
                        <div className="space-y-2">
                          <Label htmlFor="paymentReference">Payment Reference / Message (Optional)</Label>
                          <Textarea
                            id="paymentReference"
                            placeholder="Enter transaction ID, mobile money number, or any message..."
                            {...register("paymentReference")}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="paymentProof">Attach Payment Screenshot (Optional)</Label>
                          <Input
                            id="paymentProof"
                            type="file"
                            accept="image/*,application/pdf"
                            className="cursor-pointer"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) setValue("paymentProof", file);
                            }}
                          />
                          <p className="text-xs text-sage-500">Upload a screenshot of your payment confirmation.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 2: DECEASED INFO (Moved from Step 1) */}
                {currentStep === 2 && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" {...register("firstName")} placeholder="Enter first name" />
                        {errors.firstName && <p className="text-red-500 text-xs">{errors.firstName.message}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" {...register("lastName")} placeholder="Enter last name" />
                        {errors.lastName && <p className="text-red-500 text-xs">{errors.lastName.message}</p>}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="dateOfBirth">Date of Birth</Label>
                        <Input id="dateOfBirth" type="date" {...register("dateOfBirth")} />
                        {errors.dateOfBirth && <p className="text-red-500 text-xs">{errors.dateOfBirth.message}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="dateOfDeath">Date of Death</Label>
                        <Input id="dateOfDeath" type="date" {...register("dateOfDeath")} />
                        {errors.dateOfDeath && <p className="text-red-500 text-xs">{errors.dateOfDeath.message}</p>}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="county">County of Origin</Label>
                      <Select onValueChange={(value) => setValue("county", value)} defaultValue={formData.county}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a county" />
                        </SelectTrigger>
                        <SelectContent>
                          {["Bomi", "Bong", "Gbarpolu", "Grand Bassa", "Grand Cape Mount", "Grand Gedeh", "Grand Kru", "Lofa", "Margibi", "Maryland", "Montserrado", "Nimba", "River Cess", "River Gee", "Sinoe"].map((c) => (
                            <SelectItem key={c} value={c}>{c}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.county && <p className="text-red-500 text-xs">{errors.county.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Biography & Tributes</Label>
                      <Textarea
                        id="bio"
                        {...register("bio")}
                        placeholder="Share the life story, achievements, and legacy..."
                        className="min-h-[150px]"
                      />
                      <p className="text-xs text-sage-500">Tip: You can use templates like "Afterlife Journey" later.</p>
                      {errors.bio && <p className="text-red-500 text-xs">{errors.bio.message}</p>}
                    </div>
                  </div>
                )}

                {/* STEP 3: TRIBUTE DETAILS & PHOTO (Moved from Step 2) */}
                {currentStep === 3 && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="space-y-2">
                      <Label htmlFor="photo">Upload Photo</Label>
                      {/* Fixed: Functional Input for Photo Upload */}
                      <Input
                        id="photo"
                        type="file"
                        accept="image/*"
                        className="cursor-pointer"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) setValue("photo", file);
                        }}
                      />
                      <p className="text-xs text-sage-500">JPG, PNG up to 5MB. This will be the main tribute image.</p>

                      {/* Visual placeholder for design */}
                      <div className="border-2 border-dashed border-sage-300 rounded-md p-4 text-center bg-sage-50/50 mt-2">
                        <Upload className="mx-auto h-8 w-8 text-sage-400 mb-1" />
                        <p className="text-xs text-sage-500">Preview area</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="funeralDetails">Funeral & Wake Details</Label>
                      <Textarea
                        id="funeralDetails"
                        {...register("funeralDetails")}
                        placeholder="Date, time, and location of wake keeping, funeral service, and repast..."
                        className="min-h-[120px]"
                      />
                      {errors.funeralDetails && <p className="text-red-500 text-xs">{errors.funeralDetails.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ethnicNote">Cultural/Ethnic Note (Optional)</Label>
                      <Input id="ethnicNote" {...register("ethnicNote")} placeholder="e.g., Traditional rites will be observed..." />
                    </div>

                    <div className="bg-sage-50 p-4 rounded-md border border-sage-200 mt-6">
                      <h4 className="font-bold text-deep-green-900 mb-2">Ready to Submit?</h4>
                      <p className="text-sm text-sage-600">
                        By clicking "Submit", your announcement will be sent for review. Since you have selected the <strong>{formData.tier}</strong> package, please ensure your payment is completed.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between bg-sage-50/50 p-6 border-t border-sage-100">
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 1 || isSubmitting}
                  className="border-sage-300 text-sage-700"
                >
                  <ChevronLeft className="mr-2 h-4 w-4" /> Back
                </Button>

                {currentStep < 3 ? (
                  <Button type="button" onClick={nextStep} className="bg-deep-green-900 hover:bg-deep-green-800 text-white">
                    Next Step <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button type="submit" disabled={isSubmitting} className="bg-deep-green-900 hover:bg-deep-green-800 text-white min-w-[120px]">
                    {isSubmitting ? "Processing..." : "Submit Announcement"}
                  </Button>
                )}
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
