import Link from "next/link";
import Image from "next/image";
import { TributeImage } from "@/components/ui/tribute-image";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { announcements } from "@/lib/data";
import { Search, Calendar, MapPin, CheckCircle } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function Home() {
  // Create enough data for 6x6 grid (36 items) by repeating if necessary
  const baseAnnouncements = [...announcements].sort((a, b) => new Date(b.dateOfDeath).getTime() - new Date(a.dateOfDeath).getTime());
  const recentAnnouncements = Array(5).fill(baseAnnouncements).flat().slice(0, 36);

  // Specific data for sidebar as requested
  const sidebarUpdates = [
    { name: "Sarah L. Jones", date: "12/1/2025", slug: "sarah-l-jones" },
    { name: "James F. Sirleaf", date: "11/30/2025", slug: "james-f-sirleaf" },
    { name: "Samuel T. Johnson", date: "11/28/2025", slug: "samuel-t-johnson" }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-ivory-50">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-[#003B5C] text-ivory-50 py-20 md:py-32 overflow-hidden">
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            {/* Placeholder for Liberian motifs/pattern */}
            <div className="w-full h-full bg-[url('https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=1920&auto=format&fit=crop')] bg-cover bg-center opacity-30" />
          </div>

          {/* Ocean Waves */}
          <div className="ocean">
            <div className="wave"></div>
            <div className="wave"></div>
          </div>
          <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6">
              Timeless Tributes from Liberia's Heart
            </h1>
            <p className="text-lg md:text-xl text-sage-100 max-w-2xl mx-auto mb-10">
              Honoring our loved ones with dignity and grace. A communal space for remembrance, wakes, and tributes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/submit">
                <Button size="lg" className="bg-sage-500 hover:bg-sage-600 text-white w-full sm:w-auto">
                  Submit Announcement
                </Button>
              </Link>
              <Link href="/archive">
                <Button size="lg" variant="outline" className="border-sage-200 text-sage-100 hover:bg-deep-green-800 hover:text-white w-full sm:w-auto">
                  View Archive
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Search Section */}
        <section className="py-8 bg-sage-50 border-b border-sage-200">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-2xl mx-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sage-500 h-5 w-5" />
              <Input
                type="search"
                placeholder="Search by name, county, or family..."
                className="pl-10 py-6 text-lg border-sage-300 focus-visible:ring-deep-green-500"
              />
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 md:px-6 py-12 grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content - Grid */}
          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-serif font-bold text-deep-green-900">New Arrivals</h2>
              <Link href="/archive" className="text-deep-green-700 hover:underline font-medium">
                View All &rarr;
              </Link>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
              {recentAnnouncements.map((item, index) => (
                <Link key={`${item.id}-${index}`} href={`/${item.slug}`} className="group block h-full">
                  <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 border-sage-200 flex flex-col hover:-translate-y-1">
                    <div className="aspect-[4/5] relative overflow-hidden bg-sage-100">
                      <TributeImage
                        src={item.photoUrl}
                        name={item.name}
                        alt={item.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <CardContent className="p-4 flex-1 flex flex-col justify-end bg-white">
                      <h3 className="text-lg font-serif font-bold text-deep-green-900 mb-1 group-hover:text-deep-green-700 line-clamp-1 flex items-center gap-1">
                        {item.name}
                        {item.verified && <CheckCircle className="h-4 w-4 text-blue-500 fill-blue-100" />}
                      </h3>
                      <div className="flex items-center text-xs text-sage-600 mb-1">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>{new Date(item.dateOfDeath).getFullYear()}</span>
                      </div>
                      <div className="flex items-center text-xs text-sage-600">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span>{item.county}</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-1 space-y-8">
            {/* Monthly Updates */}
            <div className="bg-white p-6 rounded-lg border border-sage-200 shadow-sm">
              <h3 className="text-xl font-serif font-bold text-deep-green-900 mb-4 border-b border-sage-100 pb-2">
                Monthly Updates
              </h3>
              <p className="text-sm text-sage-600 mb-4">
                Announcements for February 2026.
              </p>
              <ul className="space-y-4">
                {sidebarUpdates.map((item, index) => (
                  <li key={index}>
                    <Link href={`/${item.slug}`} className="block group">
                      <p className="text-sm font-medium text-deep-green-900 group-hover:text-deep-green-700">
                        {item.name}
                      </p>
                      <p className="text-xs text-sage-500">
                        {item.date}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
              <div className="mt-6 pt-4 border-t border-sage-100">
                <Link href="/archive" className="text-sm text-deep-green-700 hover:underline block text-center">
                  Browse Full Archive
                </Link>
              </div>
            </div>

            {/* Support Resources */}
            <div className="bg-sage-50 p-6 rounded-lg border border-sage-200">
              <h3 className="text-lg font-serif font-bold text-deep-green-900 mb-2">
                Support & Resources
              </h3>
              <p className="text-sm text-sage-700 mb-4">
                Find counseling services, grief support groups, and community resources within the Liberian community to help you navigate this difficult time.
              </p>
              <Link href="/about">
                <Button variant="outline" className="w-full border-deep-green-900 text-deep-green-900 hover:bg-deep-green-900 hover:text-white">
                  Learn More
                </Button>
              </Link>
            </div>

            {/* Costs & Payment */}
            <div className="bg-white p-6 rounded-lg border border-sage-200 shadow-sm">
              <h3 className="text-lg font-serif font-bold text-deep-green-900 mb-2">
                Publishing Costs & Payment
              </h3>
              <p className="text-sm text-sage-700 mb-4">
                We offer affordable packages to help you honor your loved ones.
              </p>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-deep-green-800">Standard Publication</h4>
                  <p className="text-sm text-sage-600">$50</p>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-deep-green-800">Accepted Payments</h4>
                  <ul className="text-sm text-sage-600 list-disc list-inside">
                    <li>Mobile Money</li>
                    <li>Bank Transfer</li>
                    <li>Credit Card</li>
                  </ul>
                </div>
                <Link href="/contact">
                  <Button className="w-full mt-2 bg-deep-green-900 hover:bg-deep-green-800 text-white">
                    Contact to Publish
                  </Button>
                </Link>
              </div>
            </div>
          </aside>
        </div>
      </main>
      <Footer />
    </div>
  );
}
