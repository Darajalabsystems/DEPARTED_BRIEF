import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

export default function ContactPage() {
    return (
        <div className="min-h-screen flex flex-col bg-ivory-50">
            <Header />
            <main className="flex-1 container mx-auto px-4 py-12">
                <div className="max-w-4xl mx-auto">
                    <div className="text-center mb-12">
                        <h1 className="text-4xl font-serif font-bold text-deep-green-900 mb-4">Contact Us</h1>
                        <p className="text-xl text-sage-600 max-w-2xl mx-auto">
                            We are here to help you honor your loved ones. Reach out to us for any assistance.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 bg-white p-8 rounded-xl border border-sage-200 shadow-sm">
                        {/* Contact Info */}
                        <div className="space-y-8">
                            <div>
                                <h3 className="text-xl font-bold text-deep-green-900 mb-4">Get in Touch</h3>
                                <div className="space-y-4">
                                    <div className="flex items-start">
                                        <MapPin className="h-5 w-5 text-deep-green-700 mr-3 mt-1" />
                                        <div>
                                            <p className="font-semibold text-deep-green-900">Office Location</p>
                                            <p className="text-sage-600">Tubman Boulevard, Sinkor<br />Monrovia, Liberia</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start">
                                        <Phone className="h-5 w-5 text-deep-green-700 mr-3 mt-1" />
                                        <div>
                                            <p className="font-semibold text-deep-green-900">Phone</p>
                                            <p className="text-sage-600">+231 77 000 0000<br />+231 88 000 0000</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start">
                                        <Mail className="h-5 w-5 text-deep-green-700 mr-3 mt-1" />
                                        <div>
                                            <p className="font-semibold text-deep-green-900">Email</p>
                                            <p className="text-sage-600">support@departedbrief.com</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start">
                                        <Clock className="h-5 w-5 text-deep-green-700 mr-3 mt-1" />
                                        <div>
                                            <p className="font-semibold text-deep-green-900">Office Hours</p>
                                            <p className="text-sage-600">Mon - Sat: 8:00 AM - 6:00 PM<br />Sun: Closed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Contact Form */}
                        <div>
                            <h3 className="text-xl font-bold text-deep-green-900 mb-4">Send a Message</h3>
                            <form className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="name">Your Name</Label>
                                    <Input id="name" placeholder="John Doe" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="email">Email Address</Label>
                                    <Input id="email" type="email" placeholder="john@example.com" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="subject">Subject</Label>
                                    <Input id="subject" placeholder="Inquiry about..." />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="message">Message</Label>
                                    <Textarea id="message" placeholder="How can we help you?" className="min-h-[120px]" />
                                </div>
                                <Button className="w-full bg-deep-green-900 hover:bg-deep-green-800 text-white">
                                    Send Message
                                </Button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
