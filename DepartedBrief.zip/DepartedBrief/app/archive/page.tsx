import Link from "next/link";
import Image from "next/image";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { announcements } from "@/lib/data";
import { Calendar, MapPin, Search } from "lucide-react";

export default function ArchivePage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory-50">
      <Header />
      <main className="flex-1 container mx-auto px-4 md:px-6 py-12">
        <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-serif font-bold text-deep-green-900 mb-2">Archive</h1>
            <p className="text-sage-600">Browse all tributes and announcements.</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sage-500 h-4 w-4" />
              <Input placeholder="Search..." className="pl-9" />
            </div>
            <Select>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2025">2025</SelectItem>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="County" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Counties</SelectItem>
                <SelectItem value="montserrado">Montserrado</SelectItem>
                <SelectItem value="nimba">Nimba</SelectItem>
                {/* Add more */}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {announcements.map((item) => (
            <Link href={`/${item.slug}`} key={item.id} className="group">
              <Card className="h-full overflow-hidden hover:shadow-md transition-shadow border-sage-200">
                <div className="aspect-[4/5] relative overflow-hidden bg-sage-100">
                  <Image 
                    src={item.photoUrl} 
                    alt={item.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-serif font-bold text-deep-green-900 mb-1 group-hover:text-deep-green-700">
                    {item.name}
                  </h3>
                  <div className="flex items-center text-sm text-sage-600 mb-2">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{new Date(item.dateOfBirth).getFullYear()} - {new Date(item.dateOfDeath).getFullYear()}</span>
                  </div>
                  <div className="flex items-center text-sm text-sage-600">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{item.county} County</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
