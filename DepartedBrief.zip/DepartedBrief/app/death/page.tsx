import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import Link from "next/link";
import { announcements } from "@/lib/data";
import { Card, CardContent } from "@/components/ui/card";
import { TributeImage } from "@/components/ui/tribute-image";
import { Calendar, MapPin, CheckCircle } from "lucide-react";

export default function DeathPage() {
    // Create a large dataset for demonstration (duplicate to fill page)
    const baseAnnouncements = [...announcements].sort((a, b) => new Date(b.dateOfDeath).getTime() - new Date(a.dateOfDeath).getTime());
    const allAnnouncements = Array(12).fill(baseAnnouncements).flat(); // Show a LOT of items for the dedicated page

    return (
        <div className="min-h-screen flex flex-col bg-ivory-50">
            <Header />
            <main className="flex-1 container mx-auto px-4 py-12">
                <div className="flex flex-col items-center mb-12 text-center">
                    <h1 className="text-4xl font-serif font-bold text-deep-green-900 mb-4">Death Announcements</h1>
                    <p className="text-xl text-sage-600 max-w-2xl">
                        Browse all recent tributes and obituaries from our community.
                    </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {allAnnouncements.map((item, index) => (
                        <Link key={`${item.id}-${index}`} href={`/${item.slug}`} className="group block h-full">
                            <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 border-sage-200 flex flex-col hover:-translate-y-1">
                                <div className="aspect-[4/5] relative overflow-hidden bg-sage-100">
                                    <TributeImage
                                        src={item.photoUrl}
                                        name={item.name}
                                        alt={item.name}
                                        fill
                                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                                    />
                                </div>
                                <CardContent className="p-4 flex-1 flex flex-col justify-end bg-white">
                                    <h3 className="text-lg font-serif font-bold text-deep-green-900 mb-1 group-hover:text-deep-green-700 line-clamp-1 flex items-center gap-1">
                                        {item.name}
                                        {item.verified && <CheckCircle className="h-4 w-4 text-blue-500 fill-blue-100" />}
                                    </h3>
                                    <div className="flex items-center text-xs text-sage-600 mb-1">
                                        <Calendar className="h-3 w-3 mr-1" />
                                        <span>{new Date(item.dateOfDeath).getFullYear()}</span>
                                    </div>
                                    <div className="flex items-center text-xs text-sage-600">
                                        <MapPin className="h-3 w-3 mr-1" />
                                        <span>{item.county}</span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </div>
            </main>
            <Footer />
        </div>
    );
}
