import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Radio, Mic, Newspaper, Heart, Video, Globe } from "lucide-react";
import Link from "next/link";

export default function MarketingPage() {
    const services = [
        {
            title: "Obituary Publishing",
            description: "Share the life story of your loved one with our community. Includes verification and permanent archiving.",
            icon: <Newspaper className="h-10 w-10 text-deep-green-700" />,
            price: "Starting at $50",
        },
        {
            title: "Radio Announcements",
            description: "We coordinate with top local radio stations (ELBC, Truth FM, OK FM) to broadcast funeral announcements.",
            icon: <Mic className="h-10 w-10 text-deep-green-700" />,
            price: "Starting at $25",
        },
        {
            title: "Digital Tributes",
            description: "A dedicated online space for family and friends to light candles, share photos, and leave condolences.",
            icon: <Heart className="h-10 w-10 text-deep-green-700" />,
            price: "Free with Publication",
        },
        {
            title: "Live Streaming",
            description: "Professional live streaming services for wakes and funeral services for family abroad.",
            icon: <Video className="h-10 w-10 text-deep-green-700" />,
            price: "Custom Quote",
        },
        {
            title: "Memorial Programs",
            description: "Design and printing of high-quality funeral programs and souvenirs.",
            icon: <Globe className="h-10 w-10 text-deep-green-700" />,
            price: "Custom Quote",
        },
    ];

    return (
        <div className="min-h-screen flex flex-col bg-ivory-50">
            <Header />
            <main className="flex-1 container mx-auto px-4 py-12">
                <div className="text-center mb-16">
                    <h1 className="text-4xl font-serif font-bold text-deep-green-900 mb-4">Our Services</h1>
                    <p className="text-xl text-sage-600 max-w-2xl mx-auto">
                        Comprehensive media and tribute services to help you honor your loved ones with dignity.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {services.map((service, index) => (
                        <Card key={index} className="border-sage-200 hover:shadow-lg transition-shadow bg-white">
                            <CardHeader>
                                <div className="mb-4 bg-sage-50 w-16 h-16 rounded-full flex items-center justify-center">
                                    {service.icon}
                                </div>
                                <CardTitle className="text-xl font-serif font-bold text-deep-green-900">{service.title}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sage-600 mb-4">{service.description}</p>
                                <p className="font-bold text-deep-green-700">{service.price}</p>
                            </CardContent>
                            <CardFooter>
                                <Link href="/contact" className="w-full">
                                    <Button variant="outline" className="w-full border-deep-green-900 text-deep-green-900 hover:bg-deep-green-50">
                                        Inquire Now
                                    </Button>
                                </Link>
                            </CardFooter>
                        </Card>
                    ))}
                </div>

                <div className="mt-20 bg-deep-green-900 text-ivory-50 rounded-2xl p-8 md:p-12 text-center max-w-4xl mx-auto">
                    <h2 className="text-3xl font-serif font-bold mb-4">Ready to publish an announcement?</h2>
                    <p className="text-sage-200 mb-8 max-w-xl mx-auto">
                        Getting started is simple. Submit your details online or contact our support team for assistance.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Link href="/submit">
                            <Button size="lg" className="bg-white text-deep-green-900 hover:bg-sage-100">
                                Submit Online
                            </Button>
                        </Link>
                        <Link href="/contact">
                            <Button size="lg" variant="outline" className="border-white text-white hover:bg-deep-green-800">
                                Contact Support
                            </Button>
                        </Link>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
