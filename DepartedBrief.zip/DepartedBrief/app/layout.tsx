import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import { AccessibilityProvider } from "@/components/accessibility/AccessibilityProvider";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DepartedBrief.com - Timeless Tributes from Liberia's Heart",
  description: "A culturally sensitive platform for Liberian death announcements, honoring traditions like wakes, tributes, and Decoration Day.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${playfair.variable} antialiased bg-ivory-50 text-deep-green-900 dark:bg-deep-green-950 dark:text-ivory-50`}
      >
        <AccessibilityProvider>
          {children}
        </AccessibilityProvider>
      </body>
    </html>
  );
}
