import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight } from "lucide-react";
import { DownloadReceiptButton } from "@/components/confirmation/DownloadReceiptButton";

export default function ConfirmationPage() {
  // Mock data - in a real app, this would come from a database or URL params
  const receiptData = {
    orderId: "DB-2025-8392",
    submissionDate: new Date().toLocaleDateString(),
    firstName: "Joseph",
    lastName: "Doe",
    dateOfBirth: "1950-04-12",
    dateOfDeath: "2025-11-20",
    county: "Montserrado",
    bio: "A loving father and community leader who served with dignity. He was known for his kindness and generosity towards everyone he met. His legacy will live on in the hearts of those who knew him.",
    funeralDetails: "Wake keeping at St. Peter's Lutheran Church, Sinkor on Dec 10th. Funeral service follows the next day at 10 AM. Interment at the family plot.",
    ethnicNote: "Traditional rites will be observed at the family home prior to the wake.",
    tier: "premium",
    amount: "$35.00",
    paymentMethod: "mobile_money",
    paymentReference: "TXN-123456789 - Sent via MTN Mobile Money",
  };

  return (
    <div className="min-h-screen flex flex-col bg-ivory-50">
      <Header />
      <main className="flex-1 container mx-auto px-4 md:px-6 py-20 flex items-center justify-center">
        <div className="max-w-md w-full text-center space-y-8">
          <div className="flex justify-center">
            <CheckCircle className="h-20 w-20 text-deep-green-500" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-serif font-bold text-deep-green-900">Submission Received</h1>
            <p className="text-sage-700">
              Thank you for entrusting us with this tribute. Your announcement has been successfully submitted and is being processed.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg border border-sage-200 shadow-sm text-left space-y-4">
            <h3 className="font-bold text-deep-green-900 border-b border-sage-100 pb-2">Next Steps</h3>
            <ul className="space-y-3 text-sm text-sage-700">
              <li className="flex items-start gap-2">
                <span className="bg-deep-green-100 text-deep-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">1</span>
                <span>Your announcement will be reviewed and published within 24 hours.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="bg-deep-green-100 text-deep-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">2</span>
                <span>You will receive a confirmation email with a receipt and a link to the live page.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="bg-deep-green-100 text-deep-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">3</span>
                <span>You can share the link with family and friends to collect tributes.</span>
              </li>
            </ul>
          </div>

          <div className="flex flex-col gap-3">
            <DownloadReceiptButton data={receiptData} />
            <Link href="/">
              <Button className="w-full bg-deep-green-900 hover:bg-deep-green-800 text-white">
                Return Home <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
