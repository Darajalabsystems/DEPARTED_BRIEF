# DepartedBrief.com

A culturally sensitive website for Liberian death announcements, honoring traditions like wakes, tributes, and Decoration Day.

## Tech Stack

- **Framework**: Next.js 15 App Router
- **Styling**: Tailwind CSS
- **Forms**: React Hook Form + Zod
- **Icons**: Lucide React
- **Fonts**: Playfair Display (Headings), Inter (Body)

## Getting Started

1.  Install dependencies:
    ```bash
    npm install
    ```

2.  Run the development server:
    ```bash
    npm run dev
    ```

3.  Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Project Structure

-   `app/`: Next.js App Router pages and layouts.
-   `components/`: Reusable UI components.
    -   `layout/`: Header, Footer.
    -   `ui/`: Basic UI elements (Button, Input, Card, etc.).
-   `lib/`: Utility functions, data, and schemas.
-   `public/`: Static assets.

## Features

-   **Homepage**: Recent tributes, search, and monthly updates.
-   **Submit Announcement**: 3-step wizard for submitting death announcements.
-   **Announcement Page**: Detailed view with photo, bio, funeral details, and tributes.
-   **Archive**: Browse past announcements with filters.
-   **About**: Mission, FAQ, and grief resources.
-   **PDF Receipt**: Professional, downloadable PDF receipt upon submission.

## Deployment

This project is ready to be deployed on Vercel.

## License

MIT
