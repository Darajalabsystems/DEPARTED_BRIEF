"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Bell, Mail, Phone } from "lucide-react";

interface ReminderFormProps {
    announcementTitle: string;
    className?: string;
    onComplete?: () => void;
}

export function ReminderForm({ announcementTitle, className, onComplete }: ReminderFormProps) {
    const [method, setMethod] = useState<"email" | "phone">("email");
    const [contact, setContact] = useState("");
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Logic to save reminder preference would go here
        setSubmitted(true);
        if (onComplete) {
            setTimeout(onComplete, 2000);
        }
    };

    if (submitted) {
        return (
            <div className="text-center p-6 bg-sage-50 rounded-lg border border-sage-200">
                <div className="mx-auto w-12 h-12 bg-sage-200 rounded-full flex items-center justify-center mb-3">
                    <Bell className="h-6 w-6 text-deep-green-900" />
                </div>
                <h3 className="font-serif font-bold text-deep-green-900 mb-2">Reminders Set</h3>
                <p className="text-sm text-sage-600">
                    We will notify you about updates for {announcementTitle}.
                </p>
            </div>
        );
    }

    return (
        <div className={className}>
            <h3 className="font-serif font-bold text-lg text-deep-green-900 mb-4 flex items-center">
                <Bell className="h-5 w-5 mr-2" />
                Get Updates & Reminders
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
                <RadioGroup defaultValue="email" onValueChange={(v) => setMethod(v as "email" | "phone")}>
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="email" id="r-email" />
                        <Label htmlFor="r-email" className="flex items-center cursor-pointer">
                            <Mail className="h-4 w-4 mr-2 text-sage-500" /> Email
                        </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="phone" id="r-phone" />
                        <Label htmlFor="r-phone" className="flex items-center cursor-pointer">
                            <Phone className="h-4 w-4 mr-2 text-sage-500" /> Phone (SMS/Call)
                        </Label>
                    </div>
                </RadioGroup>

                <div className="space-y-2">
                    <Label htmlFor="contact">
                        {method === "email" ? "Email Address" : "Phone Number"}
                    </Label>
                    <Input
                        id="contact"
                        type={method === "email" ? "email" : "tel"}
                        placeholder={method === "email" ? "you@example.com" : "+231 ..."}
                        required
                        value={contact}
                        onChange={(e) => setContact(e.target.value)}
                    />
                </div>

                <div className="text-xs text-sage-600 bg-sage-50 p-3 rounded">
                    You will receive reminders for:
                    <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>14 & 27 Day Memorials</li>
                        <li>Anniversary of passing</li>
                        <li>New tributes posted</li>
                    </ul>
                </div>

                <Button type="submit" className="w-full bg-deep-green-900 hover:bg-deep-green-800">
                    Subscribe
                </Button>
            </form>
        </div>
    );
}
