"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, MessageSquare } from "lucide-react";

interface Tribute {
  id: string;
  name: string;
  message: string;
  date: string;
}

export function TributeWall() {
  const [tributes, setTributes] = useState<Tribute[]>([
    {
      id: "1",
      name: "Sarah Johnson",
      message: "A beautiful soul who will be deeply missed. Rest in peace.",
      date: new Date(Date.now() - 86400000).toLocaleDateString(),
    },
    {
      id: "2",
      name: "Emmanuel K. Doe",
      message: "Your legacy lives on in all of us. Thank you for your guidance.",
      date: new Date(Date.now() - 172800000).toLocaleDateString(),
    }
  ]);

  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      const newTribute: Tribute = {
        id: Date.now().toString(),
        name,
        message,
        date: new Date().toLocaleDateString(),
      };
      
      setTributes([newTribute, ...tributes]);
      setName("");
      setMessage("");
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div className="space-y-8">
      <Card className="border-sage-200 bg-white">
        <CardHeader>
          <CardTitle className="text-xl font-serif text-deep-green-900">Leave a Tribute</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Your Name</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Enter your name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea 
                id="message" 
                value={message} 
                onChange={(e) => setMessage(e.target.value)} 
                placeholder="Share a memory or condolence..."
                className="min-h-[100px]"
                required
              />
            </div>
            <Button 
              type="submit" 
              className="bg-deep-green-900 hover:bg-deep-green-800 text-white w-full sm:w-auto"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Posting..." : "Post Tribute"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h3 className="text-lg font-bold text-deep-green-900 flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Recent Tributes ({tributes.length})
        </h3>
        
        <div className="space-y-4">
          {tributes.map((tribute) => (
            <div key={tribute.id} className="bg-sage-50 p-6 rounded-lg border border-sage-100 animate-in fade-in slide-in-from-bottom-2">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-sage-200 flex items-center justify-center text-deep-green-900 font-bold">
                    {tribute.name.charAt(0)}
                  </div>
                  <span className="font-bold text-deep-green-900">{tribute.name}</span>
                </div>
                <span className="text-xs text-sage-500">{tribute.date}</span>
              </div>
              <p className="text-sage-800 pl-10">{tribute.message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
