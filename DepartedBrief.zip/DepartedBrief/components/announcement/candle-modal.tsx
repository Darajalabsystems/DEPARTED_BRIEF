"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Flame } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ReminderForm } from "./reminder-form";

interface CandleModalProps {
    announcementTitle: string;
    trigger?: React.ReactNode;
    onLightCandle?: () => void;
}

export function CandleModal({ announcementTitle, trigger, onLightCandle }: CandleModalProps) {
    const [open, setOpen] = useState(false);
    const [step, setStep] = useState<"details" | "payment" | "success">("details");
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmitDetails = (e: React.FormEvent) => {
        e.preventDefault();
        setStep("payment");
    };

    const handlePayment = async () => {
        setIsSubmitting(true);
        // Mock payment delay
        await new Promise((resolve) => setTimeout(resolve, 1500));
        setIsSubmitting(false);
        setStep("success");
        if (onLightCandle) {
            onLightCandle();
        }
    };

    const handleClose = () => {
        setOpen(false);
        // Reset state after transition
        setTimeout(() => {
            setStep("details");
        }, 300);
    };

    const MockPaymentForm = () => (
        <div className="space-y-4">
            <div className="bg-sage-50 p-4 rounded-md border border-sage-200">
                <h4 className="font-semibold text-deep-green-900 mb-2">Order Summary</h4>
                <div className="flex justify-between text-sm">
                    <span>Virtual Candle (29 Days)</span>
                    <span className="font-bold">$5.00</span>
                </div>
            </div>

            <RadioGroup defaultValue="card">
                <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="card" id="card" />
                    <Label htmlFor="card">Credit Card</Label>
                </div>
                <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="momo" id="momo" />
                    <Label htmlFor="momo">Mobile Money (MTN/Orange)</Label>
                </div>
            </RadioGroup>

            <div className="pt-4 flex justify-end gap-2">
                <Button variant="outline" onClick={() => setStep("details")} disabled={isSubmitting}>
                    Back
                </Button>
                <Button
                    className="bg-deep-green-900 hover:bg-deep-green-800"
                    onClick={handlePayment}
                    disabled={isSubmitting}
                >
                    {isSubmitting ? "Processing..." : "Pay $5.00 & Light Candle"}
                </Button>
            </div>
        </div>
    );

    const SuccessView = () => (
        <div className="text-center py-6 space-y-4">
            <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center">
                <Flame className="h-8 w-8 text-orange-500 fill-orange-500 animate-pulse" />
            </div>
            <h3 className="text-xl font-serif font-bold text-deep-green-900">
                This light shines for {announcementTitle}
            </h3>
            <p className="text-sage-600">
                Your candle has been lit and will burn for 29 days. We have sent a confirmation to your email.
            </p>

            <div className="bg-sage-50 p-4 rounded-md mt-6 text-left">
                <h4 className="font-bold text-sm text-deep-green-900 mb-2">Want reminders?</h4>
                <p className="text-xs text-sage-600 mb-3">
                    We can remind you when this candle is about to expire, or on important dates.
                </p>
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full">
                            Set Reminders
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Set Reminders for {announcementTitle}</DialogTitle>
                        </DialogHeader>
                        <ReminderForm announcementTitle={announcementTitle} />
                    </DialogContent>
                </Dialog>
            </div>

            <div className="pt-4">
                <Button onClick={handleClose} className="w-full">
                    Close
                </Button>
            </div>
        </div>
    );

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                {trigger}
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>
                        {step === "details" && "Light a Candle"}
                        {step === "payment" && "Complete Information"}
                        {step === "success" && "Thank You"}
                    </DialogTitle>
                    <DialogDescription>
                        {step === "details" && `Honor ${announcementTitle} with a virtual candle.`}
                        {step === "payment" && "Secure payment processing."}
                    </DialogDescription>
                </DialogHeader>

                {step === "details" && (
                    <form onSubmit={handleSubmitDetails} className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Your Name</Label>
                            <Input id="name" placeholder="Enter your name" required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="message">Message (Optional)</Label>
                            <Textarea
                                id="message"
                                placeholder="Share a brief message or prayer..."
                                className="resize-none"
                            />
                        </div>
                        <div className="pt-4 flex justify-end">
                            <Button type="submit" className="bg-deep-green-900 hover:bg-deep-green-800">
                                Continue to Payment
                            </Button>
                        </div>
                    </form>
                )}

                {step === "payment" && <MockPaymentForm />}
                {step === "success" && <SuccessView />}

            </DialogContent>
        </Dialog>
    );
}
