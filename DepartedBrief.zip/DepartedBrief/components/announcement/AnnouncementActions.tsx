"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Share2, Printer, Heart, Flame, Facebook, Twitter, Link as LinkIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CandleModal } from "./candle-modal";

interface AnnouncementActionsProps {
  tributeCount: number;
  announcementTitle: string;
}

export function AnnouncementActions({ tributeCount: initialCount, announcementTitle }: AnnouncementActionsProps) {
  const [tributeCount, setTributeCount] = useState(initialCount);
  const [hasLitCandle, setHasLitCandle] = useState(false);

  const handleLightCandle = () => {
    // This will be called by the modal on success
    setHasLitCandle(true);
    setTributeCount(prev => prev + 1);
  };

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';
  const shareText = `Honoring the life of ${announcementTitle} on DepartedBrief.com`;

  const handleShare = (platform: 'facebook' | 'twitter' | 'whatsapp' | 'copy') => {
    let url = '';
    switch (platform) {
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        window.open(url, '_blank', 'width=600,height=400');
        break;
      case 'twitter':
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
        window.open(url, '_blank', 'width=600,height=400');
        break;
      case 'whatsapp':
        url = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
        window.open(url, '_blank');
        break;
      case 'copy':
        navigator.clipboard.writeText(shareUrl);
        break;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white p-6 rounded-lg border border-sage-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between text-deep-green-900 border-b border-sage-100 pb-4">
        <span className="font-bold flex items-center">
          <Flame className={cn("h-5 w-5 mr-2 transition-colors duration-500", hasLitCandle ? "text-orange-500 fill-orange-500 animate-pulse" : "text-sage-400")} />
          {tributeCount} Candles Lit
        </span>

        {hasLitCandle ? (
          <Button
            size="sm"
            variant="secondary"
            disabled
            className="bg-orange-100 text-orange-800 border-orange-200"
          >
            Candle Lit
          </Button>
        ) : (
          <CandleModal
            announcementTitle={announcementTitle}
            onLightCandle={handleLightCandle}
            trigger={
              <Button
                size="sm"
                variant="outline"
                className="text-deep-green-900 border-deep-green-900 hover:bg-deep-green-50"
              >
                Light a Candle
              </Button>
            }
          />
        )}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="w-full justify-start">
              <Share2 className="h-4 w-4 mr-2" /> Share
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-48">
            <DropdownMenuItem onClick={() => handleShare('facebook')}>
              Facebook
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShare('twitter')}>
              Twitter
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShare('whatsapp')}>
              WhatsApp
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShare('copy')}>
              <LinkIcon className="h-4 w-4 mr-2" /> Copy Link
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="outline" className="w-full justify-start" onClick={handlePrint}>
          <Printer className="h-4 w-4 mr-2" /> Print
        </Button>
      </div>
    </div>
  );
}
