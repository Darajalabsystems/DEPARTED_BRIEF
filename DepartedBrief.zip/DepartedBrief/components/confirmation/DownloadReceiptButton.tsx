"use client";

import { PDFDownloadLink } from "@react-pdf/renderer";
import { ReceiptDocument } from "@/components/pdf/ReceiptDocument";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useEffect, useState } from "react";

interface DownloadReceiptButtonProps {
  data: {
    orderId: string;
    submissionDate: string;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    dateOfDeath: string;
    county: string;
    bio: string;
    funeralDetails: string;
    ethnicNote?: string;
    tier: string;
    amount: string;
    paymentMethod: string;
    paymentReference?: string;
  };
}

export function DownloadReceiptButton({ data }: DownloadReceiptButtonProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <Button variant="outline" className="w-full" disabled>
        <Download className="mr-2 h-4 w-4" /> Loading Receipt...
      </Button>
    );
  }

  return (
    <PDFDownloadLink
      document={<ReceiptDocument data={data} />}
      fileName={`receipt-${data.orderId}.pdf`}
      className="w-full"
    >
      {({ blob, url, loading, error }) => (
        <Button variant="outline" className="w-full" disabled={loading}>
          <Download className="mr-2 h-4 w-4" /> 
          {loading ? "Generating PDF..." : "Download Receipt (PDF)"}
        </Button>
      )}
    </PDFDownloadLink>
  );
}
