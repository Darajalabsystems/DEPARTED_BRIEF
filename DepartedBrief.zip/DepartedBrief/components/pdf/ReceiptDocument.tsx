import React from 'react';
import { Page, Text, View, Document, StyleSheet, Image, Font } from '@react-pdf/renderer';

// Register fonts if needed, but standard fonts work for now.
// Font.register({ family: 'Inter', src: '...' });

const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    backgroundColor: '#fdfdf8', // Ivory-50
    padding: 40,
    fontFamily: 'Helvetica',
  },
  header: {
    marginBottom: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#004225', // Deep Green 900
    paddingBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logoText: {
    fontSize: 24,
    color: '#004225', // Deep Green 900
    fontWeight: 'bold',
    fontFamily: 'Times-Roman', // Serif for "Playfair" feel
  },
  date: {
    fontSize: 10,
    color: '#689058', // Sage 500
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1,
  },
  title: {
    fontSize: 18,
    marginBottom: 20,
    color: '#1d2818', // Sage 900
    textAlign: 'center',
    textTransform: 'uppercase',
    letterSpacing: 2,
  },
  row: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#e3ebe0', // Sage 100
    paddingVertical: 8,
  },
  label: {
    width: '40%',
    fontSize: 12,
    color: '#517243', // Sage 600
    fontWeight: 'bold',
  },
  value: {
    width: '60%',
    fontSize: 12,
    color: '#1d2818', // Sage 900
    textAlign: 'right',
  },
  totalRow: {
    flexDirection: 'row',
    marginTop: 20,
    paddingTop: 10,
    borderTopWidth: 2,
    borderTopColor: '#004225',
  },
  totalLabel: {
    width: '40%',
    fontSize: 14,
    color: '#004225',
    fontWeight: 'bold',
  },
  totalValue: {
    width: '60%',
    fontSize: 16,
    color: '#004225',
    fontWeight: 'bold',
    textAlign: 'right',
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    textAlign: 'center',
    color: '#84a976', // Sage 400
    fontSize: 10,
    borderTopWidth: 1,
    borderTopColor: '#e3ebe0',
    paddingTop: 10,
  },
  watermark: {
    position: 'absolute',
    top: 200,
    left: 100,
    right: 100,
    opacity: 0.05,
    transform: 'rotate(-45deg)',
    fontSize: 60,
    color: '#004225',
    textAlign: 'center',
  },
  subHeader: {
    fontSize: 14,
    color: '#004225',
    fontWeight: 'bold',
    marginTop: 15,
    marginBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#e3ebe0',
    paddingBottom: 4,
  },
  longText: {
    fontSize: 10,
    color: '#1d2818',
    marginTop: 4,
    lineHeight: 1.4,
  }
});

interface ReceiptData {
  orderId: string;
  submissionDate: string;
  // Deceased Info
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  dateOfDeath: string;
  county: string;
  bio: string;
  // Details
  funeralDetails: string;
  ethnicNote?: string;
  // Order Info
  tier: string;
  amount: string;
  paymentMethod: string;
  paymentReference?: string;
}

export const ReceiptDocument = ({ data }: { data: ReceiptData }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.header}>
        <Text style={styles.logoText}>DepartedBrief</Text>
        <Text style={styles.date}>{data.submissionDate}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.title}>Submission Receipt</Text>

        <View style={styles.row}>
          <Text style={styles.label}>Order ID</Text>
          <Text style={styles.value}>{data.orderId}</Text>
        </View>

        {/* Deceased Information */}
        <Text style={styles.subHeader}>Deceased Information</Text>
        
        <View style={styles.row}>
          <Text style={styles.label}>Full Name</Text>
          <Text style={styles.value}>{data.firstName} {data.lastName}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>Date of Birth</Text>
          <Text style={styles.value}>{data.dateOfBirth}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>Date of Death</Text>
          <Text style={styles.value}>{data.dateOfDeath}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>County</Text>
          <Text style={styles.value}>{data.county}</Text>
        </View>

        <View style={{ marginTop: 8, marginBottom: 8 }}>
          <Text style={styles.label}>Biography</Text>
          <Text style={styles.longText}>{data.bio}</Text>
        </View>

        {/* Service Details */}
        <Text style={styles.subHeader}>Service Details</Text>

        <View style={{ marginTop: 8, marginBottom: 8 }}>
          <Text style={styles.label}>Funeral & Wake</Text>
          <Text style={styles.longText}>{data.funeralDetails}</Text>
        </View>

        {data.ethnicNote && (
          <View style={{ marginTop: 8, marginBottom: 8 }}>
            <Text style={styles.label}>Cultural Note</Text>
            <Text style={styles.longText}>{data.ethnicNote}</Text>
          </View>
        )}

        {/* Payment Information */}
        <Text style={styles.subHeader}>Payment Information</Text>

        <View style={styles.row}>
          <Text style={styles.label}>Package Tier</Text>
          <Text style={styles.value}>{data.tier.charAt(0).toUpperCase() + data.tier.slice(1)}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>Payment Method</Text>
          <Text style={styles.value}>{data.paymentMethod.replace('_', ' ').toUpperCase()}</Text>
        </View>

        {data.paymentReference && (
          <View style={styles.row}>
            <Text style={styles.label}>Reference / Note</Text>
            <Text style={styles.value}>{data.paymentReference}</Text>
          </View>
        )}

        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total Amount</Text>
          <Text style={styles.totalValue}>{data.amount}</Text>
        </View>
      </View>

      <Text style={styles.watermark}>PAID</Text>

      <View style={styles.footer}>
        <Text>Thank you for honoring your loved one with us.</Text>
        <Text>DepartedBrief.com - Timeless Tributes from Liberia's Heart</Text>
      </View>
    </Page>
  </Document>
);
