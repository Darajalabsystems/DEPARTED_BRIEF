"use client";

import * as React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface CarouselProps {
    children: React.ReactNode;
    className?: string;
}

export function Carousel({ children, className }: CarouselProps) {
    const scrollRef = React.useRef<HTMLDivElement>(null);
    const [canScrollLeft, setCanScrollLeft] = React.useState(false);
    const [canScrollRight, setCanScrollRight] = React.useState(true);

    const checkScroll = () => {
        if (scrollRef.current) {
            const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
            setCanScrollLeft(scrollLeft > 0);
            setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10); // buffer
        }
    };

    React.useEffect(() => {
        checkScroll();
        window.addEventListener("resize", checkScroll);
        return () => window.removeEventListener("resize", checkScroll);
    }, []);

    const scroll = (direction: "left" | "right") => {
        if (scrollRef.current) {
            const { clientWidth } = scrollRef.current;
            const scrollAmount = clientWidth * 0.8;
            scrollRef.current.scrollBy({
                left: direction === "left" ? -scrollAmount : scrollAmount,
                behavior: "smooth",
            });
            setTimeout(checkScroll, 300);
        }
    };

    return (
        <div className={cn("relative group", className)}>
            <div
                ref={scrollRef}
                onScroll={checkScroll}
                className="flex overflow-x-auto snap-x snap-mandatory gap-4 pb-4 md:pb-0 scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
                {children}
            </div>

            {canScrollLeft && (
                <Button
                    variant="outline"
                    size="icon"
                    className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 z-10 hidden md:flex bg-white/90 shadow-md border-sage-200 text-deep-green-900 rounded-full h-10 w-10"
                    onClick={() => scroll("left")}
                >
                    <ChevronLeft className="h-6 w-6" />
                    <span className="sr-only">Scroll left</span>
                </Button>
            )}

            {canScrollRight && (
                <Button
                    variant="outline"
                    size="icon"
                    className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 z-10 hidden md:flex bg-white/90 shadow-md border-sage-200 text-deep-green-900 rounded-full h-10 w-10"
                    onClick={() => scroll("right")}
                >
                    <ChevronRight className="h-6 w-6" />
                    <span className="sr-only">Scroll right</span>
                </Button>
            )}
        </div>
    );
}

export function CarouselItem({ children, className }: { children: React.ReactNode; className?: string }) {
    return (
        <div className={cn("flex-shrink-0 snap-start", className)}>
            {children}
        </div>
    );
}
