"use client";

import { useState, useEffect } from "react";
import Image, { ImageProps } from "next/image";
import { cn } from "@/lib/utils";

interface TributeImageProps extends Omit<ImageProps, "src"> {
    src?: string | null;
    name: string;
    fallbackText?: string;
}

export function TributeImage({
    src,
    name,
    fallbackText = "Rest In Peace",
    className,
    alt,
    ...props
}: TributeImageProps) {
    const [error, setError] = useState(false);
    const [imgSrc, setImgSrc] = useState<string | null>(src || null);

    useEffect(() => {
        setImgSrc(src || null);
        setError(false);
    }, [src]);

    const handleError = () => {
        setError(true);
    };

    if (error || !imgSrc) {
        const encodedText = encodeURIComponent(name || fallbackText);
        const placeholderUrl = `https://placehold.co/400x500/e2e8f0/1e293b/png?text=${encodedText}`;

        return (
            <Image
                src={placeholderUrl}
                alt={alt || name}
                className={cn("bg-sage-100", className)}
                {...props}
            />
        );
    }

    return (
        <Image
            src={imgSrc}
            alt={alt || name}
            onError={handleError}
            className={className}
            {...props}
        />
    );
}
