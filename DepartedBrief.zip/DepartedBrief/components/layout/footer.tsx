import Link from "next/link";

export function Footer() {
  return (
    <footer className="w-full border-t border-sage-200 bg-ivory-100 relative">
      <div className="h-1 w-full flex absolute top-0 left-0 right-0">
        <div className="h-full w-1/3 bg-[#BF0A30]"></div> {/* Red */}
        <div className="h-full w-1/3 bg-[#FFFFFF]"></div> {/* White */}
        <div className="h-full w-1/3 bg-[#002868]"></div> {/* Blue */}
      </div>
      <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row justify-between items-center gap-6 py-8 md:py-14">
        <div className="flex flex-col gap-2">
          <span className="text-lg font-serif font-bold text-deep-green-900">DepartedBrief</span>
          <p className="text-sm text-sage-700">Timeless Tributes from Liberia's Heart.</p>
        </div>
        <nav className="flex gap-4 text-sm text-sage-700">
          <Link href="/about" className="hover:underline">About</Link>
          <Link href="/archive" className="hover:underline">Archive</Link>
          <Link href="/privacy" className="hover:underline">Privacy</Link>
          <Link href="/terms" className="hover:underline">Terms</Link>
        </nav>
        <div className="text-sm text-sage-600">
          &copy; {new Date().getFullYear()} DepartedBrief. All rights reserved. | website by <a href="https://www.darajalabs.com" target="_blank" rel="noopener noreferrer" className="hover:underline">www.darajalabs.com</a>
        </div>
      </div>
    </footer>
  );
}
