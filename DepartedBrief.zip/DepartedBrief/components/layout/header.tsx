import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { AccessibilityMenu } from "@/components/accessibility/AccessibilityMenu";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-sage-200 bg-ivory-50/80 backdrop-blur supports-[backdrop-filter]:bg-ivory-50/60 transition-all duration-300">
      <div className="h-1 w-full flex">
        <div className="h-full w-1/3 bg-[#BF0A30]"></div> {/* Red */}
        <div className="h-full w-1/3 bg-[#FFFFFF]"></div> {/* White */}
        <div className="h-full w-1/3 bg-[#002868]"></div> {/* Blue */}
      </div>
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="text-xl font-serif font-bold text-deep-green-900">DepartedBrief</span>
        </Link>
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-deep-green-900">
          <Link href="/" className="hover:text-deep-green-700">Home</Link>
          <Link href="/death" className="hover:text-deep-green-700">Death</Link>
          <Link href="/archive" className="hover:text-deep-green-700">Archive</Link>
          <Link href="/about" className="hover:text-deep-green-700">About</Link>
          <Link href="/contact" className="hover:text-deep-green-700">Contact</Link>
          <Link href="/marketing" className="hover:text-deep-green-700">Marketing</Link>
        </nav>
        <div className="flex items-center gap-4">
          <AccessibilityMenu />
          <Button variant="ghost" size="icon" className="text-deep-green-900">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
          <Button className="bg-red-600 text-white hover:bg-red-700 flex items-center gap-2 shadow-sm">
            <div className="h-2 w-2 rounded-full bg-white animate-pulse" />
            Live
          </Button>
          <Link href="/submit">
            <Button className="bg-deep-green-900 text-ivory-50 hover:bg-deep-green-800">
              Submit Announcement
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
