"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useAccessibility } from "./AccessibilityProvider";
import { Eye, Type, Sun, Moon, Monitor, X } from "lucide-react";
import { cn } from "@/lib/utils";

export function AccessibilityMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const { 
    fontSize, setFontSize, 
    highContrast, setHighContrast, 
    grayscale, setGrayscale,
    reset 
  } = useAccessibility();
  
  const menuRef = useRef<HTMLDivElement>(null);

  // Close on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={menuRef}>
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={() => setIsOpen(!isOpen)}
        className="text-deep-green-900 hover:bg-sage-100"
        aria-label="Accessibility Options"
      >
        <Eye className="h-5 w-5" />
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-xl border border-sage-200 p-4 z-50 animate-in fade-in zoom-in-95 duration-200">
          <div className="flex justify-between items-center mb-4 border-b border-sage-100 pb-2">
            <h3 className="font-bold text-deep-green-900">Accessibility</h3>
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)} className="h-6 w-6 p-0">
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-4">
            {/* Font Size */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-sage-700 flex items-center gap-2">
                <Type className="h-4 w-4" /> Text Size
              </label>
              <div className="flex gap-2 bg-sage-50 p-1 rounded-md">
                <button 
                  onClick={() => setFontSize("normal")}
                  className={cn("flex-1 py-1 text-sm rounded transition-colors", fontSize === "normal" ? "bg-white shadow text-deep-green-900 font-bold" : "text-sage-600 hover:bg-sage-100")}
                >
                  A
                </button>
                <button 
                  onClick={() => setFontSize("large")}
                  className={cn("flex-1 py-1 text-base rounded transition-colors", fontSize === "large" ? "bg-white shadow text-deep-green-900 font-bold" : "text-sage-600 hover:bg-sage-100")}
                >
                  A+
                </button>
                <button 
                  onClick={() => setFontSize("xl")}
                  className={cn("flex-1 py-1 text-lg rounded transition-colors", fontSize === "xl" ? "bg-white shadow text-deep-green-900 font-bold" : "text-sage-600 hover:bg-sage-100")}
                >
                  A++
                </button>
              </div>
            </div>

            {/* Contrast */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-sage-700 flex items-center gap-2">
                <Sun className="h-4 w-4" /> Display
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => setHighContrast(!highContrast)}
                  className={cn("flex items-center justify-center gap-2 py-2 px-3 rounded-md border text-sm transition-colors", highContrast ? "bg-black text-white border-black" : "bg-white text-sage-700 border-sage-200 hover:bg-sage-50")}
                >
                  <span className="h-4 w-4 rounded-full border border-current bg-current"></span>
                  Contrast
                </button>
                <button 
                  onClick={() => setGrayscale(!grayscale)}
                  className={cn("flex items-center justify-center gap-2 py-2 px-3 rounded-md border text-sm transition-colors", grayscale ? "bg-gray-500 text-white border-gray-500" : "bg-white text-sage-700 border-sage-200 hover:bg-sage-50")}
                >
                  <span className="h-4 w-4 rounded-full bg-gray-400"></span>
                  Grayscale
                </button>
              </div>
            </div>

            <Button 
              variant="outline" 
              className="w-full mt-2 text-xs h-8" 
              onClick={reset}
            >
              Reset Settings
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
