"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, Square, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface ReadAloudButtonProps {
  text: string;
  className?: string;
  label?: string;
}

export function ReadAloudButton({ text, className, label = "Read Aloud" }: ReadAloudButtonProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [utterance, setUtterance] = useState<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      setIsSupported(true);
    }
  }, []);

  useEffect(() => {
    // Cleanup on unmount
    return () => {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isSpeaking]);

  const handleSpeak = () => {
    if (!isSupported) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
      return;
    }

    const newUtterance = new SpeechSynthesisUtterance(text);
    
    // Try to select a good voice
    const voices = window.speechSynthesis.getVoices();
    // Prefer a female voice if available as it's often softer for this context
    const preferredVoice = voices.find(v => v.name.includes("Female") || v.name.includes("Google US English")) || voices[0];
    if (preferredVoice) newUtterance.voice = preferredVoice;

    newUtterance.rate = 0.9; // Slightly slower
    newUtterance.pitch = 1;

    newUtterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    newUtterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    setUtterance(newUtterance);
    window.speechSynthesis.speak(newUtterance);
    setIsSpeaking(true);
  };

  if (!isSupported) return null;

  return (
    <Button 
      variant="outline" 
      size="sm" 
      onClick={handleSpeak}
      className={cn("gap-2 text-deep-green-700 border-deep-green-200 hover:bg-deep-green-50", className)}
    >
      {isSpeaking ? (
        <>
          <Square className="h-4 w-4 fill-current" />
          Stop Reading
        </>
      ) : (
        <>
          <Volume2 className="h-4 w-4" />
          {label}
        </>
      )}
    </Button>
  );
}
