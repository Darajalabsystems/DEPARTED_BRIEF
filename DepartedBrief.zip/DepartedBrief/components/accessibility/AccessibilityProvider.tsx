"use client";

import React, { createContext, useContext, useEffect, useState } from "react";

type FontSize = "normal" | "large" | "xl";

interface AccessibilityContextType {
  fontSize: FontSize;
  setFontSize: (size: FontSize) => void;
  highContrast: boolean;
  setHighContrast: (enabled: boolean) => void;
  grayscale: boolean;
  setGrayscale: (enabled: boolean) => void;
  reset: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [fontSize, setFontSize] = useState<FontSize>("normal");
  const [highContrast, setHighContrast] = useState(false);
  const [grayscale, setGrayscale] = useState(false);

  // Load preferences from localStorage on mount
  useEffect(() => {
    const savedFontSize = localStorage.getItem("a11y-fontSize") as FontSize;
    const savedHighContrast = localStorage.getItem("a11y-highContrast") === "true";
    const savedGrayscale = localStorage.getItem("a11y-grayscale") === "true";

    if (savedFontSize) setFontSize(savedFontSize);
    if (savedHighContrast) setHighContrast(savedHighContrast);
    if (savedGrayscale) setGrayscale(savedGrayscale);
  }, []);

  // Apply classes to document element
  useEffect(() => {
    const root = document.documentElement;
    
    // Reset classes
    root.classList.remove("text-lg", "text-xl", "high-contrast", "grayscale");

    // Apply Font Size
    if (fontSize === "large") root.classList.add("text-lg");
    if (fontSize === "xl") root.classList.add("text-xl");

    // Apply High Contrast
    if (highContrast) root.classList.add("high-contrast");

    // Apply Grayscale
    if (grayscale) root.classList.add("grayscale");

    // Save to localStorage
    localStorage.setItem("a11y-fontSize", fontSize);
    localStorage.setItem("a11y-highContrast", String(highContrast));
    localStorage.setItem("a11y-grayscale", String(grayscale));

  }, [fontSize, highContrast, grayscale]);

  const reset = () => {
    setFontSize("normal");
    setHighContrast(false);
    setGrayscale(false);
  };

  return (
    <AccessibilityContext.Provider
      value={{
        fontSize,
        setFontSize,
        highContrast,
        setHighContrast,
        grayscale,
        setGrayscale,
        reset,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (context === undefined) {
    throw new Error("useAccessibility must be used within an AccessibilityProvider");
  }
  return context;
}
