import { z } from "zod";

export const submitSchema = z.object({
  // Step 1
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  dateOfBirth: z.string().refine((date) => new Date(date).toString() !== 'Invalid Date', { message: "Valid date of birth is required" }),
  dateOfDeath: z.string().refine((date) => new Date(date).toString() !== 'Invalid Date', { message: "Valid date of death is required" }),
  county: z.string().min(1, "County is required"),
  bio: z.string().min(10, "Bio must be at least 10 characters"),
  
  // Step 2
  photo: z.any().optional(), // Handle file upload separately or use a string url if using a service
  funeralDetails: z.string().min(10, "Funeral details are required"),
  ethnicNote: z.string().optional(),
  
  // Step 3
  tier: z.enum(["basic", "premium", "custom"]),
  paymentMethod: z.enum(["mobile_money", "stripe", "paypal", "ecobank"]),
  paymentReference: z.string().optional(),
  paymentProof: z.any().optional(),
});

export type SubmitFormValues = z.infer<typeof submitSchema>;
