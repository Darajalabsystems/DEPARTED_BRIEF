export interface Announcement {
  id: string;
  slug: string;
  name: string;
  photoUrl: string;
  dateOfBirth: string;
  dateOfDeath: string;
  county: string;
  bio: string;
  funeralDetails: string;
  tributes: number;
  verified?: boolean;
}

export const announcements: Announcement[] = [
  {
    id: "1",
    slug: "joseph-k-doe",
    name: "Joseph K. Doe",
    photoUrl: "https://images.unsplash.com/photo-1542596594-649edbc13630?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1950-04-12",
    dateOfDeath: "2025-11-20",
    county: "Montserrado",
    bio: "A loving father and community leader who served with dignity. He was known for his kindness and generosity towards everyone he met.",
    funeralDetails: "Wake keeping at St. Peter's Lutheran Church, Sinkor on Dec 10th. Funeral service follows the next day at 10 AM.",
    tributes: 12,
    verified: true,
  },
  {
    id: "2",
    slug: "mary-s-brown",
    name: "Mary S. Brown",
    photoUrl: "https://images.unsplash.com/photo-1589156280159-27698a70f29e?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1965-08-22",
    dateOfDeath: "2025-11-25",
    county: "Nimba",
    bio: "A dedicated teacher who inspired generations. Her legacy lives on in the students she taught and the lives she touched.",
    funeralDetails: "Funeral service at Ganta Methodist Church on Dec 12th. Interment at the family plot in Sanniquellie.",
    tributes: 8,
    verified: true,
  },
  {
    id: "3",
    slug: "samuel-t-johnson",
    name: "Samuel T. Johnson",
    photoUrl: "https://images.unsplash.com/photo-1506277886164-e25aa3f4ef7f?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1948-01-15",
    dateOfDeath: "2025-11-28",
    county: "Bong",
    bio: "A pillar of the community and a friend to all. He served as a deacon for over 30 years.",
    funeralDetails: "Interment at Gbarnga Cemetery on Dec 15th. Repast at the Johnson Residence.",
    tributes: 24,
  },
  {
    id: "4",
    slug: "elizabeth-k-tubman",
    name: "Elizabeth K. Tubman",
    photoUrl: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1955-03-10",
    dateOfDeath: "2025-11-15",
    county: "Maryland",
    bio: "A matriarch who held the family together with love and prayer.",
    funeralDetails: "Service at Harper Episcopal Church.",
    tributes: 15,
    verified: true,
  },
  {
    id: "5",
    slug: "james-f-sirleaf",
    name: "James F. Sirleaf",
    photoUrl: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1970-11-05",
    dateOfDeath: "2025-11-30",
    county: "Bomi",
    bio: "A hardworking farmer and cherished brother.",
    funeralDetails: "Burial in Tubmanburg.",
    tributes: 5,
  },
  {
    id: "6",
    slug: "sarah-l-jones",
    name: "Sarah L. Jones",
    photoUrl: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1980-02-14",
    dateOfDeath: "2025-12-01",
    county: "Grand Bassa",
    bio: "Her smile lit up every room. Gone too soon.",
    funeralDetails: "Wake at Buchanan Baptist Church.",
    tributes: 30,
    verified: true,
  },
  {
    id: "7",
    slug: "david-m-kamara",
    name: "David M. Kamara",
    photoUrl: "https://images.unsplash.com/photo-1522556189639-b150ed9c4330?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1960-06-30",
    dateOfDeath: "2025-11-18",
    county: "Lofa",
    bio: "A respected elder and keeper of tradition.",
    funeralDetails: "Traditional ceremony in Voinjama.",
    tributes: 42,
  },
  {
    id: "8",
    slug: "grace-p-williams",
    name: "Grace P. Williams",
    photoUrl: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?q=80&w=400&auto=format&fit=crop",
    dateOfBirth: "1990-09-09",
    dateOfDeath: "2025-11-22",
    county: "Sinoe",
    bio: "A vibrant soul who loved music and dance.",
    funeralDetails: "Service at Greenville City Hall.",
    tributes: 18,
    verified: true,
  }
];
